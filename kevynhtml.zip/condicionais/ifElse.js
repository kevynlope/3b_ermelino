const idade = 30;

// CHEGAR ESSA IDADE
// CASO A IDADE SEJA MAIOR OU IGUAL A 18 ANOS,
// DETERMINAR PASSAGEM GARANTIDA OU PROIBIDA
// CASO CONTRÁRIO INFORME ERRO!
// REFATORAÇÃO - REESTRUTURAR
// ANINHAR       - ENCADEAR


// if (idade >= 55) {
//   console.log("idosos não podem entrar");
// }
// else if (idade < 55) {
//   console.log("idosos não podem entrar!");
//   if (idade >= 18) {
//     console.log("passagem garantida");
//   }
// }
// TESTAR PESSOA MENOR DE 18
const convidados = ['Batman', 'Superman', 'Mulher Maravilha', 'Homem de Ferro',]



